# The Aetherium v0.3 — Knowledge Engine

Static GitHub Pages site. Upload `index.html` and the entire `assets/` folder to the root of your existing repository.

## The Curator
This release includes a clearly labeled **curated Q&A preview**, not a generative AI chatbot. It responds only to predefined topics and includes source links. It does not call any AI API or collect messages.

## Real AI upgrade
Deploy a secure server-side endpoint (e.g., a serverless function) to call a language model. Keep API keys only in server environment variables, never in browser JavaScript or a public GitHub repo. Add rate limits, abuse controls, privacy notices, and retrieval of vetted Compendium articles with citations. GitHub Pages alone cannot securely host an AI API key.

## Sources
CERN: https://home.cern/science/physics/standard-model
NASA: https://science.nasa.gov/universe/gravitational-waves/
Stanford Encyclopedia: https://plato.stanford.edu/entries/qm/ and https://plato.stanford.edu/entries/properties-emergent/
