# The Aetherium v0.2 — The Living Compendium

Static GitHub Pages website. Includes interactive topic search, Nexus connections, world detail overlays, and artwork. No backend or accounts yet.

## Deploy
Upload the contents of this folder (index.html and assets/) to the root of your public GitHub repository. GitHub Pages should deploy from main / (root).

This release contains introductory subject descriptions, not a sourced scientific encyclopedia. Research articles, citations, and community contributions are planned for future versions.
